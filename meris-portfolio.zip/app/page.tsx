import Hero from "@/components/hero"
import Skills from "@/components/skills"
import Projects from "@/components/projects"
import About from "@/components/about"
import Blog from "@/components/blog"
import Contact from "@/components/contact"
import NeuralNetwork from "@/components/neural-network"

export default function Home() {
  return (
    <main className="min-h-screen bg-primary-dark text-primary-light overflow-x-hidden">
      <NeuralNetwork />
      <Hero />
      <Skills />
      <Projects />
      <About />
      <Blog />
      <Contact />
    </main>
  )
}

