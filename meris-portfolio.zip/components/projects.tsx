"use client"

import { useRef } from "react"
import Image from "next/image"
import { motion, useInView } from "framer-motion"
import { ExternalLink, Github } from "lucide-react"
import { Button } from "@/components/ui/button"

const projects = [
  {
    title: "AI-Powered Customer Support Chatbot",
    description:
      "An intelligent chatbot that handles customer inquiries, reduces response time, and improves satisfaction.",
    image: "/placeholder.svg?height=600&width=800",
    tech: "GPT-4, LangChain, Node.js",
    outcome: "Reduced response time by 40%",
    link: "#",
    github: "#",
  },
  {
    title: "Business Process Automation Tool",
    description: "End-to-end automation solution for document processing, data extraction, and workflow management.",
    image: "/placeholder.svg?height=600&width=800",
    tech: "Python, RPA, OCR, Flask",
    outcome: "Saved 200+ hours/month",
    link: "#",
    github: "#",
  },
  {
    title: "LLM Prompt Optimization Framework",
    description: "A framework for testing, optimizing, and managing prompts for large language models.",
    image: "/placeholder.svg?height=600&width=800",
    tech: "Custom GPT-4 templates, React",
    outcome: "Improved task accuracy by 35%",
    link: "#",
    github: "#",
  },
  {
    title: "Predictive Analytics Model",
    description: "Machine learning model that predicts customer behavior and provides actionable insights.",
    image: "/placeholder.svg?height=600&width=800",
    tech: "PyTorch, Scikit-learn, Pandas",
    outcome: "92% prediction accuracy",
    link: "#",
    github: "#",
  },
]

export default function Projects() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <section id="projects" className="py-20 md:py-28 bg-primary-dark/50">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 inline-block relative">
            My Work
            <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-primary-neon"></span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-300">
            Explore my portfolio of AI projects that demonstrate my expertise in developing intelligent solutions.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className="bg-secondary-dark rounded-xl overflow-hidden shadow-lg group"
            >
              <div className="relative h-64 overflow-hidden">
                <Image
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary-dark to-transparent opacity-0 group-hover:opacity-70 transition-opacity duration-300"></div>
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex gap-3">
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-primary-dark/80 border-primary-neon text-primary-light hover:bg-primary-neon hover:text-primary-dark"
                    asChild
                  >
                    <a href={project.link} target="_blank" rel="noopener noreferrer">
                      <ExternalLink size={16} className="mr-2" />
                      View Demo
                    </a>
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-primary-dark/80 border-primary-neon text-primary-light hover:bg-primary-neon hover:text-primary-dark"
                    asChild
                  >
                    <a href={project.github} target="_blank" rel="noopener noreferrer">
                      <Github size={16} className="mr-2" />
                      Code
                    </a>
                  </Button>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-gray-300 mb-4">{project.description}</p>
                <div className="flex flex-wrap justify-between">
                  <span className="text-primary-neon text-sm font-medium">{project.tech}</span>
                  <span className="text-gray-300 text-sm font-medium">{project.outcome}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button
            size="lg"
            variant="outline"
            className="border-primary-neon text-primary-light hover:text-primary-dark hover:bg-primary-neon transition-all"
          >
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  )
}

