"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

export default function Hero() {
  const typewriterRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const typewriterElement = typewriterRef.current
    if (!typewriterElement) return

    const phrases = ["AI Developer & Prompt Engineer", "Chatbot Specialist", "Automation Expert", "ML Enthusiast"]

    let currentPhraseIndex = 0
    let currentCharIndex = 0
    let isDeleting = false
    let typingSpeed = 100

    const type = () => {
      const currentPhrase = phrases[currentPhraseIndex]

      if (isDeleting) {
        typewriterElement.textContent = currentPhrase.substring(0, currentCharIndex - 1)
        currentCharIndex--
        typingSpeed = 50
      } else {
        typewriterElement.textContent = currentPhrase.substring(0, currentCharIndex + 1)
        currentCharIndex++
        typingSpeed = 100
      }

      if (!isDeleting && currentCharIndex === currentPhrase.length) {
        isDeleting = true
        typingSpeed = 1500 // Pause at the end
      } else if (isDeleting && currentCharIndex === 0) {
        isDeleting = false
        currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length
        typingSpeed = 500 // Pause before typing next phrase
      }

      setTimeout(type, typingSpeed)
    }

    setTimeout(type, 1000)
  }, [])

  return (
    <section id="home" className="min-h-screen flex items-center pt-20 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          className="max-w-3xl"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Meris
            <br />
            <span ref={typewriterRef} className="text-primary-neon typewriter">
              AI Developer & Prompt Engineer
            </span>
          </h1>

          <motion.p
            className="text-lg md:text-xl mb-8 max-w-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            Building intelligent solutions with AI/ML, automation, and precision prompts. Transforming ideas into
            powerful AI applications that solve real-world problems.
          </motion.p>

          <motion.div
            className="flex flex-wrap gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <Button
              size="lg"
              className="bg-primary-neon hover:bg-primary-neon/80 text-primary-dark font-medium"
              asChild
            >
              <a href="#projects">View Projects</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-neon text-primary-light hover:text-primary-dark hover:bg-primary-neon transition-all"
              asChild
            >
              <a href="#contact">Contact Me</a>
            </Button>
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 hidden md:block"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.8 }}
      >
        <a
          href="#skills"
          className="flex flex-col items-center text-primary-light/70 hover:text-primary-neon transition-colors"
        >
          <span className="mb-2 text-sm">Scroll Down</span>
          <div className="w-6 h-10 border-2 border-primary-light/30 rounded-full flex justify-center">
            <div className="w-1.5 h-1.5 bg-primary-neon rounded-full mt-2 animate-bounce"></div>
          </div>
        </a>
      </motion.div>
    </section>
  )
}

