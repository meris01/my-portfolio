"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Brain, Bot, Zap, Key } from "lucide-react"

const skills = [
  {
    icon: <Zap size={40} className="text-primary-neon" />,
    title: "AI Automation",
    description:
      "Streamlining workflows and processes with intelligent automation solutions that save time and reduce errors.",
    tools: "Tools: Python, UiPath, APIs, Zapier",
  },
  {
    icon: <Bot size={40} className="text-primary-neon" />,
    title: "AI Chatbots",
    description: "Creating conversational agents that deliver exceptional user experiences and provide 24/7 support.",
    tools: "Platforms: Dialogflow, GPT-4, LangChain, Rasa",
  },
  {
    icon: <Brain size={40} className="text-primary-neon" />,
    title: "AI/ML Development",
    description: "Building intelligent systems that learn and adapt to complex data patterns for predictive analytics.",
    tools: "Frameworks: TensorFlow, PyTorch, scikit-learn",
  },
  {
    icon: <Key size={40} className="text-primary-neon" />,
    title: "Prompt Engineering",
    description:
      "Crafting precise instructions that unlock the full potential of large language models for specific tasks.",
    tools: "Optimization, LLM fine-tuning, RAG systems",
  },
]

export default function Skills() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  return (
    <section id="skills" className="py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 inline-block relative">
            What I Do
            <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-primary-neon"></span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-300">
            Leveraging cutting-edge AI technologies to solve complex problems and create innovative solutions.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className="bg-secondary-dark rounded-xl p-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-2 group"
            >
              <div className="mb-6 p-4 rounded-full bg-primary-dark/50 inline-block group-hover:scale-110 transition-transform">
                {skill.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{skill.title}</h3>
              <p className="text-gray-300 mb-4">{skill.description}</p>
              <div className="text-sm text-primary-neon font-medium">{skill.tools}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

