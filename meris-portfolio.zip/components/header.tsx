"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? "bg-primary-dark/90 backdrop-blur-md py-4 shadow-lg" : "py-6"}`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <nav className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-primary-neon">
            Meris
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <ul className="flex space-x-6">
              <li>
                <Link
                  href="#skills"
                  className="text-primary-light hover:text-primary-neon transition-colors relative after:absolute after:bottom-[-5px] after:left-0 after:h-0.5 after:w-0 after:bg-primary-neon after:transition-all hover:after:w-full"
                >
                  Skills
                </Link>
              </li>
              <li>
                <Link
                  href="#projects"
                  className="text-primary-light hover:text-primary-neon transition-colors relative after:absolute after:bottom-[-5px] after:left-0 after:h-0.5 after:w-0 after:bg-primary-neon after:transition-all hover:after:w-full"
                >
                  Projects
                </Link>
              </li>
              <li>
                <Link
                  href="#about"
                  className="text-primary-light hover:text-primary-neon transition-colors relative after:absolute after:bottom-[-5px] after:left-0 after:h-0.5 after:w-0 after:bg-primary-neon after:transition-all hover:after:w-full"
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  href="#blog"
                  className="text-primary-light hover:text-primary-neon transition-colors relative after:absolute after:bottom-[-5px] after:left-0 after:h-0.5 after:w-0 after:bg-primary-neon after:transition-all hover:after:w-full"
                >
                  Insights
                </Link>
              </li>
              <li>
                <Link
                  href="#contact"
                  className="text-primary-light hover:text-primary-neon transition-colors relative after:absolute after:bottom-[-5px] after:left-0 after:h-0.5 after:w-0 after:bg-primary-neon after:transition-all hover:after:w-full"
                >
                  Contact
                </Link>
              </li>
            </ul>
            <Button
              variant="outline"
              className="border-primary-neon text-primary-light hover:text-primary-dark hover:bg-primary-neon transition-all"
            >
              Download Resume
            </Button>
          </div>

          <button className="md:hidden text-primary-light" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>
      </div>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 bg-primary-dark/95 z-40 flex flex-col items-center justify-center transition-transform duration-300 ease-in-out ${isMenuOpen ? "translate-x-0" : "translate-x-full"} md:hidden`}
      >
        <nav className="flex flex-col items-center space-y-8">
          <Link
            href="#skills"
            className="text-xl text-primary-light hover:text-primary-neon transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Skills
          </Link>
          <Link
            href="#projects"
            className="text-xl text-primary-light hover:text-primary-neon transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Projects
          </Link>
          <Link
            href="#about"
            className="text-xl text-primary-light hover:text-primary-neon transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            About
          </Link>
          <Link
            href="#blog"
            className="text-xl text-primary-light hover:text-primary-neon transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Insights
          </Link>
          <Link
            href="#contact"
            className="text-xl text-primary-light hover:text-primary-neon transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </Link>
          <Button
            variant="outline"
            className="mt-4 border-primary-neon text-primary-light hover:text-primary-dark hover:bg-primary-neon transition-all"
          >
            Download Resume
          </Button>
        </nav>
      </div>
    </header>
  )
}

