"use client"

import { useRef } from "react"
import Image from "next/image"
import { motion, useInView } from "framer-motion"
import { ArrowRight, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"

const blogPosts = [
  {
    title: "How to Design Effective AI Chatbots in 2024",
    excerpt: "Learn the key principles and techniques for creating chatbots that deliver exceptional user experiences.",
    image: "/placeholder.svg?height=600&width=800",
    date: "March 2, 2024",
    link: "#",
  },
  {
    title: "5 Prompt Engineering Hacks for Better LLM Outputs",
    excerpt: "Discover advanced techniques to improve the quality and relevance of your LLM responses.",
    image: "/placeholder.svg?height=600&width=800",
    date: "February 15, 2024",
    link: "#",
  },
  {
    title: "Automating Workflows with Python: A Step-by-Step Guide",
    excerpt: "A comprehensive guide to identifying, designing, and implementing automated workflows with Python.",
    image: "/placeholder.svg?height=600&width=800",
    date: "January 20, 2024",
    link: "#",
  },
]

export default function Blog() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <section id="blog" className="py-20 md:py-28 bg-primary-dark/50">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 inline-block relative">
            AI Insights
            <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-primary-neon"></span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-300">
            Thoughts, tutorials, and insights on AI development, prompt engineering, and automation.
          </p>
        </motion.div>

        <div ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className="bg-secondary-dark rounded-xl overflow-hidden shadow-lg group"
            >
              <a href={post.link} className="block">
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center text-sm text-primary-neon mb-3">
                    <Calendar size={14} className="mr-2" />
                    {post.date}
                  </div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary-neon transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-gray-300 mb-4">{post.excerpt}</p>
                  <div className="flex items-center text-primary-neon font-medium">
                    Read More
                    <ArrowRight size={16} className="ml-2 group-hover:translate-x-2 transition-transform" />
                  </div>
                </div>
              </a>
            </motion.article>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button
            size="lg"
            variant="outline"
            className="border-primary-neon text-primary-light hover:text-primary-dark hover:bg-primary-neon transition-all"
          >
            View All Articles
          </Button>
        </div>
      </div>
    </section>
  )
}

