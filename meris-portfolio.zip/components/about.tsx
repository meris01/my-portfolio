"use client"

import { useRef } from "react"
import Image from "next/image"
import { motion, useInView } from "framer-motion"
import { Award, Briefcase, GraduationCap } from "lucide-react"

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  return (
    <section id="about" className="py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-3xl md:text-4xl font-bold mb-16 text-center inline-block relative"
        >
          About Meris
          <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-primary-neon"></span>
        </motion.h2>

        <div ref={ref} className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <motion.div
            className="lg:col-span-4 relative"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative mx-auto lg:mx-0 max-w-sm">
              <div className="absolute -top-4 -left-4 w-full h-full border-2 border-primary-neon rounded-xl"></div>
              <div className="relative overflow-hidden rounded-xl">
                <Image
                  src="/placeholder.svg?height=600&width=600"
                  alt="Meris Profile"
                  width={400}
                  height={500}
                  className="object-cover"
                />
              </div>
            </div>
          </motion.div>

          <motion.div
            className="lg:col-span-8"
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-2xl font-bold mb-4">AI Developer & Prompt Engineer</h3>
            <p className="text-gray-300 mb-6 text-lg">
              I'm an AI developer passionate about turning complex problems into automated solutions. With 3+ years of
              experience, I've built chatbots for 10+ clients and optimized LLM prompts for Fortune 500 teams.
            </p>
            <p className="text-gray-300 mb-8 text-lg">
              My approach combines technical expertise with a deep understanding of business needs to create AI
              solutions that deliver measurable results and provide exceptional user experiences.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="flex items-start">
                <div className="mr-4 p-3 bg-primary-dark rounded-lg">
                  <Briefcase className="text-primary-neon" size={24} />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Experience</h4>
                  <p className="text-gray-300">3+ Years</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mr-4 p-3 bg-primary-dark rounded-lg">
                  <GraduationCap className="text-primary-neon" size={24} />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Education</h4>
                  <p className="text-gray-300">MSc in AI</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mr-4 p-3 bg-primary-dark rounded-lg">
                  <Award className="text-primary-neon" size={24} />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Projects</h4>
                  <p className="text-gray-300">20+ Completed</p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <div className="bg-primary-dark/50 border border-primary-neon/20 rounded-full px-4 py-2 text-sm flex items-center">
                <Award size={16} className="text-primary-neon mr-2" />
                AWS Certified ML Specialist
              </div>
              <div className="bg-primary-dark/50 border border-primary-neon/20 rounded-full px-4 py-2 text-sm flex items-center">
                <Award size={16} className="text-primary-neon mr-2" />
                DeepLearning.AI Prompt Engineering
              </div>
              <div className="bg-primary-dark/50 border border-primary-neon/20 rounded-full px-4 py-2 text-sm flex items-center">
                <Award size={16} className="text-primary-neon mr-2" />
                Google Cloud AI Professional
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

